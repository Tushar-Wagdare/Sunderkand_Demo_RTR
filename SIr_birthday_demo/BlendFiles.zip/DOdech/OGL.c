// Windows Header Files
#include <Windows.h> //Win32 API
#include "OGL.h"  // our header file
#include <stdio.h>   // for File IO
#include <stdlib.h>   // for Exit()

//OpenGL Header Files
#include <gl/GL.h>
//OpenGL Graphics Library Utility
#include <gl/GLU.h>

// Macros
#define WIN_WIDTH 800
#define WIN_HEIGHT 600

int winWidth;
int winHeight;


//link with OpenGL Library
#pragma comment(lib, "OpenGL32.lib")
#pragma comment(lib, "glu32.lib")

//Global Function Declarations
LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM); //in _far memory

// Global Variables Declarations
FILE *gpFILE = NULL;

HWND ghwnd = NULL;
BOOL gbActive = FALSE;
DWORD dwStyle = 0;
WINDOWPLACEMENT wpPrev = { sizeof(WINDOWPLACEMENT) };
BOOL gbFullscreen = FALSE;

//OpenGL related Global Variables
HDC ghdc = NULL;
HGLRC ghrc = NULL;

GLfloat pAngle = 0.0f;

int day = 0;
int year = 0;

GLUquadric *quadric = NULL;

//Entry Point Function
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdLine, int iCmdShow)
{
	// Functions Declarations
	int initialise(void);
	void uninitialise(void);
	void display(void);
	void update(void);

	//Local Variable Declarations
	WNDCLASSEX wndclass;
	HWND hwnd;
	MSG msg;
	TCHAR szAppName[] = TEXT("PSS_Window");
	int iResult = 0;
	BOOL bDone = FALSE;

	// Variables For Centering_of_window
	int ScreenWidth = GetSystemMetrics(SM_CXSCREEN); //1920
	int ScreenHeight = GetSystemMetrics(SM_CYSCREEN); //1080
	int MyWindowWidth = 800;
	int MyWindowHeight = 600;
	int x = (ScreenWidth - MyWindowWidth) / 2;   // 560 
	int y = (ScreenHeight - MyWindowHeight) / 2;   // 240

	//code
	gpFILE = fopen("Log.txt", "w");
	if (gpFILE == NULL)
	{
		MessageBox(NULL, TEXT("Log File Cannot Be Opened"), TEXT("Error"), MB_OK | MB_ICONERROR);
		exit(0);
	}
	fprintf(gpFILE, "Program Started Successfully...\n");

	//wndclss Ex Initilization
	wndclass.cbSize = sizeof(WNDCLASSEX);
	wndclass.style = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
	wndclass.cbClsExtra = 0;
	wndclass.cbWndExtra = 0;
	wndclass.lpfnWndProc = WndProc;
	wndclass.hInstance = hInstance;
	wndclass.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
	wndclass.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(MYICON));
	wndclass.hCursor = LoadCursor(NULL, IDC_ARROW);
	wndclass.lpszClassName = szAppName;
	wndclass.lpszMenuName = NULL;
	wndclass.hIconSm = LoadIcon(hInstance, MAKEINTRESOURCE(MYICON));


	//Register WNDCLASSEX
	RegisterClassEx(&wndclass);

	//Create Window
	hwnd = CreateWindowEx(
		WS_EX_APPWINDOW,
		szAppName,
		TEXT("Pranav_Sawale_Chi_Window!"),
		WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN | WS_CLIPSIBLINGS | WS_VISIBLE,
		x,
		y,
		WIN_WIDTH,
		WIN_HEIGHT,
		NULL,
		NULL,
		hInstance,
		NULL);

	ghwnd = hwnd;

	//Initilization
	iResult = initialise();
	if (iResult != 0)
	{
		MessageBox(hwnd, TEXT("initialise() Failed"), TEXT("Error"), MB_OK | MB_ICONERROR);
		DestroyWindow(hwnd);
	}

	//Show The Window
	ShowWindow(hwnd, iCmdShow);
	SetForegroundWindow(hwnd);
	SetFocus(hwnd);

	//Paint/Redraw The Window
	//UpdateWindow(hwnd); he nako karan he wm_paint la lagta

#pragma region TIMER VARIABLES

	LARGE_INTEGER frequency;    //The frequency of the performance counter
	LARGE_INTEGER startCounter; //counter value at start of the frame
	LARGE_INTEGER endCounter;  //counter value at end of frame

	double elapsedTime = 0.0;  //Elapsed time between two frames
	double frameCount = 0.0;  //Number of frames since laste FPS update
	double fps = 0.0;  // Current FPS value

	char titleBuffer[256];
	//

	//Initliazing the frequency and start counter
	QueryPerformanceFrequency(&frequency);
	QueryPerformanceCounter(&startCounter);

#pragma endregion

	// GAME LOOP
	while (bDone == FALSE)
	{
		QueryPerformanceCounter(&endCounter);
		elapsedTime = (double)((endCounter.QuadPart - startCounter.QuadPart) / (frequency.QuadPart));

		if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
		{
			if (msg.message == WM_QUIT)
				bDone = TRUE;
			else
			{
				TranslateMessage(&msg);
				DispatchMessage(&msg);
			}
		}
		else
		{
			if (gbActive == TRUE)
			{
				// RENDER
				display();

				// UPDATE
				update();

				// Increment frame count
				frameCount += 1.0;

				// If One second has passed, update FPS value and reset the frame count and counter
				if (elapsedTime >= 0.5)
				{
					fps = frameCount / elapsedTime;
					frameCount = 0.0;
					QueryPerformanceCounter(&startCounter);
				}

				sprintf(titleBuffer, "FPS: %.2f | Dimensions: W(%d) X H(%d)", fps, winWidth, winHeight);
				SetWindowText(hwnd, titleBuffer);

			}
		}
	}

	//UnInitilization
	uninitialise();

	return((int)msg.wParam);
}

//Callback Function
LRESULT CALLBACK WndProc(HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
	//Function Declarations
	void ToggleFullscreen(void);
	void resize(int, int);

	// Code
	switch (iMsg)
	{
	case WM_SETFOCUS:
		gbActive = TRUE;
		break;
	case WM_KILLFOCUS:
		gbActive = FALSE;
		break;
	case WM_SIZE:
		winWidth = LOWORD(lParam);
		winHeight = HIWORD(lParam);
		resize(winWidth, winHeight);
		break;
	case WM_ERASEBKGND:
		return(0);
		break;// simply comment this case
	case WM_KEYDOWN:
		switch (LOWORD(wParam))
		{
		case VK_ESCAPE:
			DestroyWindow(hwnd);
			break;
		}
		break;
	case WM_CHAR:
		switch (LOWORD(wParam))
		{
		case 'F':
		case 'f':
			if (gbFullscreen == FALSE)
			{
				ToggleFullscreen();
				gbFullscreen = TRUE;
			}
			else
			{
				ToggleFullscreen();
				gbFullscreen = FALSE;
			}
			break;

		case 'D':
			day  = (day + 6) % 360;
			break;
		
		case 'd':
			day  = (day - 6) % 360;
			break;

		case 'Y':
			year = (year + 3) % 360;
			break;

		case 'y':
			year = (year - 3) % 360;
			break;

		default:
			break;
		}
		break;
	case WM_CLOSE:
		DestroyWindow(hwnd);
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	default:
		break;
	}

	return(DefWindowProc(hwnd, iMsg, wParam, lParam));
}

// Our function
void ToggleFullscreen(void)
{
	// Local Variable Declarations
	MONITORINFO mi = { sizeof(MONITORINFO) };

	// CODE

	//******************(1)*********************
	if (gbFullscreen == FALSE)
	{	// [A]
		dwStyle = GetWindowLong(ghwnd, GWL_STYLE);
		if (dwStyle & WS_OVERLAPPEDWINDOW)
		{
			// a, b, c
			if (GetWindowPlacement(ghwnd, &wpPrev) && GetMonitorInfo(MonitorFromWindow(ghwnd, MONITORINFOF_PRIMARY), &mi))
			{   // i>
				SetWindowLong(ghwnd, GWL_STYLE, dwStyle & ~WS_OVERLAPPEDWINDOW);
				// ii>
				SetWindowPos(ghwnd, HWND_TOP, mi.rcMonitor.left, mi.rcMonitor.top, mi.rcMonitor.right - mi.rcMonitor.left, mi.rcMonitor.bottom - mi.rcMonitor.top, SWP_NOZORDER | SWP_FRAMECHANGED);
			}
		}
		// [B]
		ShowCursor(FALSE);
	}
	//*******************(2)********************
	else
	{   // [A]
		SetWindowPlacement(ghwnd, &wpPrev);
		// [B]
		SetWindowLong(ghwnd, GWL_STYLE, dwStyle | WS_OVERLAPPEDWINDOW);
		// [C]
		SetWindowPos(ghwnd, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOOWNERZORDER | SWP_NOZORDER | SWP_FRAMECHANGED);
		// [D]
		ShowCursor(TRUE);
	}

}

int initialise(void)
{
	//Function Prototype
	void resize(int, int);

	//Function Declarations
	PIXELFORMATDESCRIPTOR pfd;
	int iPixelFormatIndex = 0;
	ZeroMemory(&pfd, sizeof(PIXELFORMATDESCRIPTOR));

	//Initilization of PIXELFORMATDESCRIPTOR
	pfd.nSize      = sizeof(PIXELFORMATDESCRIPTOR);
	pfd.nVersion   = 1;
	pfd.dwFlags    = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
	pfd.iPixelType = PFD_TYPE_RGBA;
	pfd.cColorBits = 32;
	pfd.cRedBits   = 8;
	pfd.cGreenBits = 8;
	pfd.cBlueBits  = 8;
	pfd.cAlphaBits = 8;
	pfd.cDepthBits = 32;    // First Change (compulsory)

	//2nd step -> Get the DC
	ghdc = GetDC(ghwnd);
	if (ghdc == NULL)
	{
		fprintf(gpFILE, "GetDc() Failed.\n");
		return(-1);
	}

	//3rd step -> choose
	iPixelFormatIndex = ChoosePixelFormat(ghdc, &pfd);
	if (iPixelFormatIndex == 0)
	{
		fprintf(gpFILE, "ChoosePixelFormat() Failed.\n");
		return(-2);
	}

	//4th step -> set obtained pixel format
	if (SetPixelFormat(ghdc, iPixelFormatIndex, &pfd) == FALSE)
	{
		fprintf(gpFILE, "SetPixelFormat() Failed.\n");
		return(-3);
	}

	//5th step -> tell WGL Bridging Library to give me OpenGl Compatible DC form this DC
	ghrc = wglCreateContext(ghdc);
	if (ghrc == NULL)
	{
		fprintf(gpFILE, "wglCreateContext() Failed.\n");
		return(-4);
	}

	//6th step -> make rendering context current
	if (wglMakeCurrent(ghdc, ghrc) == FALSE)
	{
		fprintf(gpFILE, "wglMakeCurrent() Failed.\n");
		return(-5);
	}

	// Enabling Depth // Second Change
	glShadeModel(GL_SMOOTH); // (optional) beautification
	glClearDepth(1.0f);      // (compulsory) 
	glEnable(GL_DEPTH_TEST); // (compulsory) out of 8 tests enable depth test only
	glDepthFunc(GL_LEQUAL);  // (compulsory) compare karyana sathi <= with glClearDepth(1.0f)
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST); // (optional) beautification


	//*********************HERE OPENGL STARTS*********************
	//Set the clear color of window to blue
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

	// Initialise Quadric
	quadric = gluNewQuadric();

	//WarmUp resize call
	resize(WIN_WIDTH, WIN_HEIGHT);

	return(0);
}

void resize(int width, int height) 
{
	//CODE
	if (height <= 0)
		height = 1;

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	gluPerspective(45.0f, (GLfloat)width / (GLfloat)height, 0.1f, 100.0f);

	glViewport(0, 0, (GLsizei)width, (GLsizei)height);

}

void display(void)
{
	void drawDodecahedron(void);

	//CODE
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); // Third Change (compulsory)


	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	// View Transformation
	//gluLookAt(0.0f, 0.0f, 5.0f,   0.0f, 0.0f, 0.0f,   0.0f, 1.0f, 0.0f);

	
	drawDodecahedron();

	SwapBuffers(ghdc);
}

void update(void)
{
	//CODE
	
}

void uninitialise(void)
{
	//Function Declarations
	void ToggleFullscreen(void);

	//CODE
	// if application is exiting in fullscreen
	if (gbFullscreen == TRUE)
	{
		ToggleFullscreen();
		gbFullscreen = FALSE;
	}

	//make the hdc as current dc
	if (wglGetCurrentContext() == ghrc)
	{
		wglMakeCurrent(NULL, NULL);
	}

	//Delete Rendering Context
	if (ghrc)
	{
		wglDeleteContext(ghrc);
		ghrc = NULL;
	}

	//Delete the ghdc
	if (ghdc)
	{
		ReleaseDC(ghwnd, ghdc);
		ghdc = NULL;
	}

	//Destroy Window
	if (ghwnd)
	{
		DestroyWindow(ghwnd);
		ghwnd = NULL;
	}

	//Delete quadric
	if (quadric)
	{
		gluDeleteQuadric(quadric);
		quadric = NULL;
	}

	//close the log file
	if (gpFILE)
	{
		fprintf(gpFILE, "Program Ended Successfully...\n");
		fclose(gpFILE);
		gpFILE = NULL;
	}
}

void drawDodecahedron(void)
{
	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	glLoadIdentity();
	glTranslatef(0.0f, 0.0f, -2.5f);

	glPointSize(10);

	float d = 100.0f;
	//************************************************
	//glBegin(GL_LINES);

	glColor3f(1.0f, 0.0f, 0.0f);

	glVertex3f(-1.0f, 1.0f, 0.0f);
	glVertex3f(1.0f, -1.0f, 0.0f);

	glVertex3f(1.0f, 1.0f, 0.0f);
	glVertex3f(-1.0f, -1.0f, 0.0f);

	glVertex3f(0.0f, 1.0f, 0.0f);
	glVertex3f(0.0f, -1.0f, 0.0f);

	glVertex3f(-1.0f, 0.0f, 0.0f);
	glVertex3f(1.0f, 0.0f, 0.0f);

	glEnd();
	//*************************************************

	//Background Shadding
	glBegin(GL_QUADS);
	glColor3f(0.0f, 0.016f, 0.259f);
	glVertex3f(-1.0f, 1.0f, 0.0f);

	glColor3f(0.0f, 0.0f, 0.0f);
	glVertex3f(1.0f, 1.0f, 0.0f);

	glColor3f(0.078f, 0.102f, 0.161f);
	glVertex3f(1.0f, -1.0f, 0.0f);

	glColor3f(0.078f, 0.102f, 0.161f);
	glVertex3f(-1.0f, -1.0f, 0.0f);
	glEnd();

	glBegin(GL_TRIANGLES);
	glColor3f(0.961f, 0.8f, 0.867f);
	glVertex3f(0.0f, 0.0f / d, 0.0f);
	glVertex3f(31.6543f / d, 10.1159f / d, 0.0f);
	glVertex3f(0.0f, 33.1067f / d, 0.0f);
	glEnd();
	glBegin(GL_TRIANGLES);
	glColor3f(0.843f, 0.69f, 0.804f);
	glVertex3f(-0.0f, 0.0f / d, 0.0f);
	glVertex3f(-31.6543f / d, 10.1159f / d, 0.0f);
	glVertex3f(-0.0f, 33.1067f / d, 0.0f);
	glEnd();

	//
	glBegin(GL_TRIANGLES);
	glColor3f(1.0f, 1.0f, 1.0f);
	glVertex3f(-0.0f, 33.1067f / d, 0.0f);
	glVertex3f(31.6543f / d, 10.1159f / d, 0.0f);
	glVertex3f(50.9066f / d, 69.1541f / d, 0.0f);
	glEnd();
	glBegin(GL_TRIANGLES);
	glColor3f(1.0f, 1.0f, 1.0f);
	glVertex3f(-0.0f, 33.1067f / d, 0.0f);
	glVertex3f(-31.6543f / d, 10.1159f / d, 0.0f);
	glVertex3f(-50.9066f / d, 69.1541f / d, 0.0f);
	glEnd();

	//
	glBegin(GL_TRIANGLES);
	glColor3f(0.918f, 0.733f, 0.875f);
	glVertex3f(0.0f, 33.1067f / d, 0.0f);
	glVertex3f(50.9066f / d, 69.1541f / d, 0.0f);
	glVertex3f(0.0f / d, 53.2288f / d, 0.0f);
	glEnd();
	glBegin(GL_TRIANGLES);
	glColor3f(1.0f, 0.808f, 0.925f);
	glVertex3f(-0.0f, 33.1067f / d, 0.0f);
	glVertex3f(-50.9066f / d, 69.1541f / d, 0.0f);
	glVertex3f(-0.0f / d, 53.2288f / d, 0.0f);
	glEnd();

	//
	glBegin(GL_TRIANGLES);
	glColor3f(0.992f, 0.816f, 0.898f);
	glVertex3f(0.0f / d, 53.2288f / d, 0.0f);
	glVertex3f(19.7992f / d, 59.3936f / d, 0.0f);
	glVertex3f(0.0f / d, 84.1469f / d, 0.0f);
	glEnd();
	glBegin(GL_TRIANGLES);
	glColor3f(0.933f, 0.765f, 0.875f);
	glVertex3f(0.0f / d, 53.2288f / d, 0.0f);
	glVertex3f(-19.7992f / d, 59.3936f / d, 0.0f);
	glVertex3f(0.0f / d, 84.1469f / d, 0.0f);
	glEnd();

	//
	glBegin(GL_TRIANGLES);
	glColor3f(0.667f, 0.514f, 0.69f);
	glVertex3f(0.0f, 0.0f, 0.0f);
	glVertex3f(31.6543f / d, 10.1159f / d, 0.0f);
	glVertex3f(20.0158f / d, -26.7925f / d, 0.0f);
	glEnd();
	glBegin(GL_TRIANGLES);
	glColor3f(0.667f, 0.514f, 0.69f);
	glVertex3f(0.0f, 0.0f, 0.0f);
	glVertex3f(-31.6543f / d, 10.1159f / d, 0.0f);
	glVertex3f(-20.0158f / d, -26.7925f / d, 0.0f);
	glEnd();

	//
	glBegin(GL_TRIANGLES);
	glColor3f(0.439f, 0.38f, 0.604f);
	glVertex3f(0.0f, 0.0f, 0.0f);
	glVertex3f(0.0f / d, -26.7925f / d, 0.0f);
	glVertex3f(20.0158f / d, -26.7925f / d, 0.0f);
	glEnd();
	glBegin(GL_TRIANGLES);
	glColor3f(0.439f, 0.38f, 0.604f);
	glVertex3f(-0.0f, 0.0f, 0.0f);
	glVertex3f(-0.0f / d, -26.7925f / d, 0.0f);
	glVertex3f(-20.0158f / d, -26.7925f / d, 0.0f);
	glEnd();

	//
	glBegin(GL_TRIANGLES);
	glColor3f(1.0f, 1.0f, 1.0f);
	glVertex3f(0.0f / d, -26.7925f / d, 0.0f);
	glVertex3f(0.0f, -89.1611f / d, 0.0f);
	glVertex3f(20.0158f / d, -26.7925f / d, 0.0f);
	glEnd();
	glBegin(GL_TRIANGLES);
	glColor3f(1.0f, 1.0f, 1.0f);
	glVertex3f(0.0f / d, -26.7925f / d, 0.0f);
	glVertex3f(0.0f, -89.1611f / d, 0.0f);
	glVertex3f(-20.0158f / d, -26.7925f / d, 0.0f);
	glEnd();

	//
	glBegin(GL_TRIANGLES);
	glColor3f(0.722f, 0.565f, 0.745f);
	glVertex3f(0.0f, -89.1611f / d, 0.0f);
	glVertex3f(32.6351f / d, -43.8002f / d, 0.0f);
	glVertex3f(20.0158f / d, -26.7925f / d, 0.0f);
	glEnd();
	glBegin(GL_TRIANGLES);
	glColor3f(0.722f, 0.565f, 0.745f);
	glVertex3f(0.0f, -89.1611f / d, 0.0f);
	glVertex3f(-32.6351f / d, -43.8002f / d, 0.0f);
	glVertex3f(-20.0158f / d, -26.7925f / d, 0.0f);
	glEnd();

	//
	glBegin(GL_TRIANGLES);
	glColor3f(0.475f, 0.42f, 0.647f);
	glVertex3f(20.0158f / d, -26.7925f / d, 0.0f);
	glVertex3f(32.6351f / d, -43.8002f / d, 0.0f);
	glVertex3f(83.7191f / d, -26.6913f / d, 0.0f);
	glEnd();
	glBegin(GL_TRIANGLES);
	glColor3f(0.475f, 0.42f, 0.647f);
	glVertex3f(-20.0158f / d, -26.7925f / d, 0.0f);
	glVertex3f(-32.6351f / d, -43.8002f / d, 0.0f);
	glVertex3f(-83.7191f / d, -26.6913f / d, 0.0f);
	glEnd();

	//
	glBegin(GL_TRIANGLES);
	glColor3f(0.475f, 0.42f, 0.647f);
	glVertex3f(20.4418f / d, -60.7668f / d, 0.0f);
	glVertex3f(52.8746f / d, -71.4657f / d, 0.0f);
	glVertex3f(32.6351f / d, -43.8002f / d, 0.0f);
	glEnd();
	glBegin(GL_TRIANGLES);
	glColor3f(0.475f, 0.42f, 0.647f);
	glVertex3f(-20.4418f / d, -60.7668f / d, 0.0f);
	glVertex3f(-52.8746f / d, -71.4657f / d, 0.0f);
	glVertex3f(-32.6351f / d, -43.8002f / d, 0.0f);
	glEnd();

	//
	glBegin(GL_TRIANGLES);
	glColor3f(0.82f, 0.663f, 0.867f);
	glVertex3f(32.6351f / d, -43.8002f / d, 0.0f);
	glVertex3f(52.8746f / d, -71.4657f / d, 0.0f);
	glVertex3f(52.2026f / d, -37.2327f / d, 0.0f);
	glEnd();
	glBegin(GL_TRIANGLES);
	glColor3f(0.82f, 0.663f, 0.867f);
	glVertex3f(-32.6351f / d, -43.8002f / d, 0.0f);
	glVertex3f(-52.8746f / d, -71.4657f / d, 0.0f);
	glVertex3f(-52.2026f / d, -37.2327f / d, 0.0f);
	glEnd();

	//
	glBegin(GL_TRIANGLES);
	glColor3f(1.0f, 1.0f, 1.0f);
	glVertex3f(20.0158f / d, -26.7925f / d, 0.0f);
	glVertex3f(83.7191f / d, -26.7925f / d, 0.0f);
	glVertex3f(31.6543f / d, 10.1159f / d, 0.0f);
	glEnd();
	glBegin(GL_TRIANGLES);
	glColor3f(1.0f, 1.0f, 1.0f);
	glVertex3f(-20.0158f / d, -26.7925f / d, 0.0f);
	glVertex3f(-83.7191f / d, -26.7925f / d, 0.0f);
	glVertex3f(-31.6543f / d, 10.1159f / d, 0.0f);
	glEnd();

	//
	glBegin(GL_TRIANGLES);
	glColor3f(0.788f, 0.631f, 0.827f);
	glVertex3f(31.6543f / d, 10.1159f / d, 0.0f);
	glVertex3f(83.7191f / d, -26.7925f / d, 0.0f);
	glVertex3f(51.5837f / d, 16.8601f / d, 0.0f);
	glEnd();
	glBegin(GL_TRIANGLES);
	glColor3f(0.788f, 0.631f, 0.827f);
	glVertex3f(-31.6543f / d, 10.1159f / d, 0.0f);
	glVertex3f(-83.7191f / d, -26.7925f / d, 0.0f);
	glVertex3f(-51.5837f / d, 16.8601f / d, 0.0f);
	glEnd();

	//
	glBegin(GL_TRIANGLES);
	glColor3f(0.757f, 0.6f, 0.796f);
	glVertex3f(51.5837f / d, 16.8601f / d, 0.0f);
	glVertex3f(63.2309f / d, 0.251085f / d, 0.0f);
	glVertex3f(82.6769f / d, 26.8875f / d, 0.0f);
	glEnd();
	glBegin(GL_TRIANGLES);
	glColor3f(0.757f, 0.6f, 0.796f);
	glVertex3f(-51.5837f / d, 16.8601f / d, 0.0f);
	glVertex3f(-63.2309f / d, 0.251085f / d, 0.0f);
	glVertex3f(-82.6769f / d, 26.8875f / d, 0.0f);
	glEnd();

	//
	glBegin(GL_TRIANGLES);
	glColor3f(0.655f, 0.506f, 0.69f);
	glVertex3f(31.6543f / d, 10.1159f / d, 0.0f);
	glVertex3f(51.5837f / d, 16.8601f / d, 0.0f);
	glVertex3f(50.9066f / d, 69.1541f / d, 0.0f);
	glEnd();
	glBegin(GL_TRIANGLES);
	glColor3f(0.655f, 0.506f, 0.69f);
	glVertex3f(-31.6543f / d, 10.1159f / d, 0.0f);
	glVertex3f(-51.5837f / d, 16.8601f / d, 0.0f);
	glVertex3f(-50.9066f / d, 69.1541f / d, 0.0f);
	glEnd();

	//
	glBegin(GL_TRIANGLES);
	glColor3f(0.925f, 0.757f, 0.867f);
	glVertex3f(51.5837f / d, 16.8601f / d, 0.0f);
	glVertex3f(82.6769f / d, 26.8875f / d, 0.0f);
	glVertex3f(51.2297f / d, 36.7969f / d, 0.0f);
	glEnd();
	glBegin(GL_TRIANGLES);
	glColor3f(0.875f, 0.675f, 0.804f);
	glVertex3f(-51.5837f / d, 16.8601f / d, 0.0f);
	glVertex3f(-82.6769f / d, 26.8875f / d, 0.0f);
	glVertex3f(-51.2297f / d, 36.7969f / d, 0.0f);
	glEnd();
}

