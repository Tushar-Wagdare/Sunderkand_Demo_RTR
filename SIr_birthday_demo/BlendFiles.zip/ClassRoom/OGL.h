
#pragma once

#define MYICON 101

//************************ Sir's Audio ************************
#define KALLA_KA_SANGA_MALA 1
